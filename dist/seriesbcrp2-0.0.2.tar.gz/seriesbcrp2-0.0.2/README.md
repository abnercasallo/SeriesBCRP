#   SeriesBCRP
This repository will contain a package to work with time series from BCRP

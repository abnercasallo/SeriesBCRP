from setuptools import find_packages, setup

setup(
    name='seriesbcrperu',
    version='0.0.2',
    packages=find_packages()
)